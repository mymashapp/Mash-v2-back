namespace Aimo.Web;

public static partial class WebDefaults
{
    public const string AppSettingsFilePath = "App_Data/appsettings.json";
}