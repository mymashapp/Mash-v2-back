namespace Aimo.Web.Framework;

public static partial class WebFrameworkDefaults
{
    public const string Prefix = ".Aimo";
    public const string UserUniqueId = "Uid";
    public const string Email = "email";
    
    


}