﻿namespace Aimo.Domain.Users
{
    public class PictureDto : Dto
    {
        public byte[] Picture { get; set; }
    }
}
