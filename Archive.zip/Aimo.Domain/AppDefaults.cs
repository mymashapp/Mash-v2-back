namespace Aimo.Domain;

public static partial class AppDefaults
{
}