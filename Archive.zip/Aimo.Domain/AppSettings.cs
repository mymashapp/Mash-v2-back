﻿namespace Aimo.Domain;

public partial class AppSettings //TODO:bind from json file
{

}