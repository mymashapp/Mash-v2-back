namespace Aimo.Core;

public static class ResultMessage
{
    public const string NotFound = "Not found";
    public const string NullObject = "Object is null";
}