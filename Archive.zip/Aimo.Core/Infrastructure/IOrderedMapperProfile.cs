﻿namespace Aimo.Core.Infrastructure;

public partial interface IOrderedMapperProfile
{
    int Order { get; }
}