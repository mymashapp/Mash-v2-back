﻿namespace Aimo.Core;

public static partial class AimoDefaults
{
    public const string AppName = "MASHAPI";
    public const int DefaultPageSize = 10;
}